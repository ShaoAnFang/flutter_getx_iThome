import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:it_home/pages/FirstPageController.dart';

class FirstPage extends GetView<FirstPageController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text('FirstPage')),
        body: SafeArea(
          child: Container(
            color: Colors.grey[50],
            child: ListView.builder(
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                itemCount: controller.dataList.length,
                itemBuilder: (BuildContext context, int index) {
                  final title = controller.dataList[index];
                  return GestureDetector(
                    child: Card(
                      elevation: 3.0,
                      child: ListTile(
                        title: Text(title),
                        trailing: Icon(Icons.arrow_forward_ios),
                      ),
                    ),
                    onTap: () => Get.toNamed(title),
                  );
                }),
          ),
        ));
  }
}
