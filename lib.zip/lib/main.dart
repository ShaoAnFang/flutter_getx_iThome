import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:it_home/routes/app_pages.dart';
import 'package:it_home/utils/UserDefault.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await UserDefault().init();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      // home: ApplicationPage(),
      initialRoute: AppPages.initPage,
      getPages: AppPages.routes,
      enableLog: true,
    );
  }
}
