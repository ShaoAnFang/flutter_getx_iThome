import 'package:get/get.dart';
import 'package:it_home/pages/Lottie/LottiePage.dart';
import 'package:it_home/pages/carousel_slider/CarouselSlidePage.dart';
import 'package:it_home/pages/FirstPage.dart';
import 'package:it_home/pages/image_pick/ImagePickerPage.dart';
import 'package:it_home/routes/PagesBind.dart';

part 'app_routes.dart';

class AppPages {
  static const initPage = AppRoutes.FirstPage;
  static final routes = [
    GetPage(
      name: AppRoutes.FirstPage,
      page: () => FirstPage(),
      binding: PagesBind(),
      // children: [
      // GetPage(
      //   name: AppRoutes.LoginDetail,
      //   page: () => LoginDetailView(),
      //   binding: PagesBind(),
      //   transition: Transition.rightToLeftWithFade,
      //   transitionDuration: Duration(milliseconds: 500),
      //   // fullscreenDialog: true,
      //   // opaque: false,
      // ),
      // ],
    ),
    GetPage(
      name: AppRoutes.CarouselSlidePage,
      page: () => CarouselSlidePage(),
      binding: PagesBind(),
    ),
    GetPage(
      name: AppRoutes.LottiePage,
      page: () => LottiePage(),
      binding: PagesBind(),
    ),
    GetPage(
      name: AppRoutes.ImagePickerPage,
      page: () => ImagePickerPage(),
      binding: PagesBind(),
    ),




  ];
}
