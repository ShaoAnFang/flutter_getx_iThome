import 'package:get/get.dart';
import 'package:it_home/pages/Lottie/LottiePageController.dart';
import 'package:it_home/pages/carousel_slider/CarouselSlidePageController.dart';
import 'package:it_home/pages/FirstPageController.dart';
import 'package:it_home/pages/image_pick/ImagePickerPageController.dart';

class PagesBind extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<FirstPageController>(() => FirstPageController());
    Get.lazyPut<CarouselSlidePageController>(() => CarouselSlidePageController());
    Get.lazyPut<LottiePageController>(() => LottiePageController());
    Get.lazyPut<ImagePickPageController>(() => ImagePickPageController());
  }
}
