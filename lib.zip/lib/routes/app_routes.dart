part of 'app_pages.dart';

abstract class AppRoutes {
  static const FirstPage = "/FirstPage";
  static const CarouselSlidePage = '/CarouselSlidePage';
  static const LottiePage = '/LottiePage';
  static const ImagePickerPage = '/ImagePickerPage';
}
